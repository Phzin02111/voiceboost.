# Voice Boost — Android (v2)

- Escolha uma palavra ou frase; quando o app ouvir, sobe o volume e toca um alarme ou o seu MP3.
- Funciona com a tela apagada ou o app fechado (serviço em primeiro plano, com notificação).
- Reconhecimento offline (Vosk, modelo pt-BR baixado na primeira abertura, ~31 MB).
- Botões na notificação: "Parar som" e "Desligar".
