package com.voiceboost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import java.io.File
import java.text.Normalizer
import kotlin.concurrent.thread

class VoiceService : Service() {

    companion object {
        const val ACTION_START = "com.voiceboost.START"
        const val ACTION_STOP_SOUND = "com.voiceboost.STOP_SOUND"
        const val ACTION_QUIT = "com.voiceboost.QUIT"
        private const val CHANNEL = "voiceboost_listen"
        private const val NOTIF_ID = 7

        @Volatile var running = false
        @Volatile var playing = false
        @Volatile var lastHeard = ""
        @Volatile var lastError = ""
    }

    private val handler = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null
    private var wake: PowerManager.WakeLock? = null
    private var originalVolume = -1
    @Volatile private var wordRegex: Regex? = null
    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> reloadWord() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        reloadWord()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_SOUND -> { stopSound(); return START_NOT_STICKY }
            ACTION_QUIT -> { shutdown(); return START_NOT_STICKY }
        }
        try {
            val n = buildNotification("Ouvindo a palavra “${Prefs.word(this)}”")
            if (Build.VERSION.SDK_INT >= 30) {
                startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIF_ID, n)
            }
        } catch (e: Exception) {
            lastError = "Não foi possível iniciar em segundo plano: ${e.message}"
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) startListening()
        return START_NOT_STICKY
    }

    private fun normalize(s: String): String =
        Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD)
            .replace(Regex("\\p{Mn}+"), "")
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex(" +"), " ")
            .trim()

    private fun reloadWord() {
        val w = normalize(Prefs.word(this))
        wordRegex = if (w.isEmpty()) null else Regex("(^| )" + Regex.escape(w) + "( |$)")
    }

    private fun startListening() {
        if (!ModelManager.isReady(this)) {
            lastError = "Modelo de voz não baixado."
            stopSelf()
            return
        }
        lastError = ""
        lastHeard = ""
        running = true
        wake = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "voiceboost:listen").apply { acquire() }

        thread(name = "VoiceBoostListen") {
            var model: Model? = null
            var rec: Recognizer? = null
            var audio: AudioRecord? = null
            try {
                model = Model(ModelManager.modelDir(this).absolutePath)
                rec = Recognizer(model, 16000f)
                val min = AudioRecord.getMinBufferSize(16000, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                audio = AudioRecord(
                    MediaRecorder.AudioSource.MIC, 16000, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 16000)
                )
                if (audio.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("Microfone indisponível")
                audio.startRecording()
                val buf = ShortArray(2048)
                var wasPlaying = false
                while (running) {
                    val n = audio.read(buf, 0, buf.size)
                    if (n < 0) throw IllegalStateException("Erro ao ler o microfone")
                    if (n == 0) continue
                    if (playing) { wasPlaying = true; continue }
                    if (wasPlaying) { rec.reset(); wasPlaying = false }
                    val isFinal = rec.acceptWaveForm(buf, n)
                    val text = if (isFinal) JSONObject(rec.result).optString("text")
                    else JSONObject(rec.partialResult).optString("partial")
                    if (text.isNotEmpty()) lastHeard = text
                    val rx = wordRegex
                    if (rx != null && rx.containsMatchIn(normalize(text))) {
                        playing = true
                        rec.reset()
                        handler.post { trigger() }
                    }
                }
            } catch (e: Throwable) {
                lastError = e.message ?: "Erro desconhecido"
            } finally {
                try { audio?.stop() } catch (_: Exception) { }
                audio?.release()
                try { rec?.close() } catch (_: Throwable) { }
                try { model?.close() } catch (_: Throwable) { }
                running = false
                handler.post { shutdown() }
            }
        }
    }

    private fun trigger() {
        if (!running) { playing = false; return }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        originalVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val start = originalVolume
        updateNotification("Palavra detectada! Tocando…")
        startPlayer()
        var step = 0
        val ramp = object : Runnable {
            override fun run() {
                if (!playing) return
                step++
                val v = start + (max - start) * step / 12
                try { am.setStreamVolume(AudioManager.STREAM_MUSIC, v, 0) } catch (_: SecurityException) { }
                if (step < 12) handler.postDelayed(this, 100)
            }
        }
        handler.post(ramp)
    }

    private fun startPlayer() {
        val mp = MediaPlayer()
        try {
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            val custom = File(filesDir, "custom_audio")
            if (Prefs.source(this) == "mp3" && custom.exists()) {
                mp.setDataSource(custom.absolutePath)
            } else {
                val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                    ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
                mp.setDataSource(this, uri)
            }
            mp.isLooping = true
            mp.setOnPreparedListener { it.start() }
            mp.setOnErrorListener { _, _, _ -> stopSound(); true }
            mp.prepareAsync()
            player = mp
        } catch (e: Exception) {
            mp.release()
            lastError = "Não consegui tocar o áudio: ${e.message}"
            stopSound()
        }
    }

    private fun stopSound() {
        handler.removeCallbacksAndMessages(null)
        player?.let {
            try { it.stop() } catch (_: Exception) { }
            it.release()
        }
        player = null
        if (originalVolume >= 0) {
            try {
                val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.setStreamVolume(AudioManager.STREAM_MUSIC, originalVolume, 0)
            } catch (_: Exception) { }
            originalVolume = -1
        }
        playing = false
        if (running) updateNotification("Ouvindo a palavra “${Prefs.word(this)}”")
    }

    private fun shutdown() {
        running = false
        stopSound()
        stopForeground(true)
        stopSelf()
    }

    override fun onDestroy() {
        running = false
        playing = false
        handler.removeCallbacksAndMessages(null)
        player?.release()
        player = null
        try { Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener) } catch (_: Exception) { }
        try { if (wake?.isHeld == true) wake?.release() } catch (_: Exception) { }
        super.onDestroy()
    }

    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Escuta de voz", NotificationManager.IMPORTANCE_LOW))
        }
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), flags)
        val stopSound = PendingIntent.getService(
            this, 1, Intent(this, VoiceService::class.java).setAction(ACTION_STOP_SOUND), flags
        )
        val quit = PendingIntent.getService(
            this, 2, Intent(this, VoiceService::class.java).setAction(ACTION_QUIT), flags
        )
        return NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Voice Boost")
            .setContentText(text)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(0, "Parar som", stopSound)
            .addAction(0, "Desligar", quit)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
