package com.voiceboost.app

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object ModelManager {
    private val URLS = listOf(
        "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip",
        "https://huggingface.co/rhasspy/vosk-models/resolve/main/pt/vosk-model-small-pt-0.3.zip"
    )

    @Volatile var lastError = ""

    fun modelDir(c: Context): File = File(c.filesDir, "vosk-model")
    fun isReady(c: Context): Boolean = File(modelDir(c), "am").isDirectory

    private fun open(first: String): HttpURLConnection {
        var u = first
        for (i in 0 until 8) {
            val conn = URL(u).openConnection() as HttpURLConnection
            conn.instanceFollowRedirects = false
            conn.connectTimeout = 20000
            conn.readTimeout = 40000
            conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) VoiceBoost")
            val code = conn.responseCode
            if (code in 300..399) {
                val loc = conn.getHeaderField("Location") ?: throw IOException("redirecionamento sem destino")
                u = URL(URL(u), loc).toString()
                conn.disconnect()
                continue
            }
            if (code != 200) throw IOException("HTTP $code")
            return conn
        }
        throw IOException("redirecionamentos demais")
    }

    private fun describe(zip: File, entries: Int, dir: File): String {
        val head = try {
            zip.inputStream().use { i ->
                val b = ByteArray(40)
                val n = i.read(b)
                if (n <= 0) "" else String(b, 0, n, Charsets.ISO_8859_1).filter { it.code in 32..126 }
            }
        } catch (_: Exception) { "?" }
        val top = dir.list()?.take(5)?.joinToString(",") ?: ""
        return "modelo não achado (zip ${zip.length()} bytes, $entries entradas, início='$head', pastas=[$top])"
    }

    /** Baixa e extrai o modelo de voz em português. Rodar fora da thread principal. */
    fun download(c: Context, onProgress: (Int) -> Unit): Boolean {
        val tmpZip = File(c.cacheDir, "model.zip")
        val tmpDir = File(c.cacheDir, "model_tmp")
        lastError = ""
        val errors = mutableListOf<String>()
        for (url in URLS) {
            try {
                tmpZip.delete()
                tmpDir.deleteRecursively()
                tmpDir.mkdirs()
                val conn = open(url)
                val total = conn.contentLength
                conn.inputStream.use { input ->
                    tmpZip.outputStream().use { out ->
                        val buf = ByteArray(32 * 1024)
                        var done = 0L
                        var n = 0
                        while (input.read(buf).also { n = it } >= 0) {
                            out.write(buf, 0, n)
                            done += n
                            if (total > 0) onProgress((done * 90 / total).toInt())
                        }
                    }
                }
                conn.disconnect()
                val base = tmpDir.canonicalPath
                var entries = 0
                ZipInputStream(tmpZip.inputStream().buffered()).use { zin ->
                    var e = zin.nextEntry
                    while (e != null) {
                        entries++
                        val f = File(tmpDir, e.name)
                        if (!f.canonicalPath.startsWith(base)) throw SecurityException("zip inválido")
                        if (e.isDirectory) {
                            f.mkdirs()
                        } else {
                            f.parentFile?.mkdirs()
                            f.outputStream().use { zin.copyTo(it) }
                        }
                        e = zin.nextEntry
                    }
                }
                val mdl = tmpDir.walkTopDown().firstOrNull { it.isFile && it.name == "final.mdl" }
                val found = mdl?.parentFile?.parentFile
                    ?: throw IOException(describe(tmpZip, entries, tmpDir))
                val dir = modelDir(c)
                dir.deleteRecursively()
                if (!found.renameTo(dir)) {
                    found.copyRecursively(dir, true)
                }
                tmpZip.delete()
                tmpDir.deleteRecursively()
                onProgress(100)
                if (isReady(c)) return true
                errors.add("modelo incompleto")
            } catch (e: Throwable) {
                errors.add("${e.javaClass.simpleName}: ${e.message}")
            }
        }
        tmpZip.delete()
        tmpDir.deleteRecursively()
        modelDir(c).deleteRecursively()
        lastError = errors.joinToString(" | ")
        return false
    }
}
