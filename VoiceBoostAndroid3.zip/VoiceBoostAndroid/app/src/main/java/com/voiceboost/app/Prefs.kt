package com.voiceboost.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    const val FILE = "voiceboost"
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)
    fun word(c: Context): String = sp(c).getString("word", "socorro") ?: "socorro"
    fun setWord(c: Context, v: String) { sp(c).edit().putString("word", v).apply() }
    fun source(c: Context): String = sp(c).getString("source", "alarm") ?: "alarm"
    fun setSource(c: Context, v: String) { sp(c).edit().putString("source", v).apply() }
    fun mp3Name(c: Context): String = sp(c).getString("mp3name", "") ?: ""
    fun setMp3Name(c: Context, v: String) { sp(c).edit().putString("mp3name", v).apply() }
}
