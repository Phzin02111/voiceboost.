package com.voiceboost.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.net.Uri
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val reqPerm = 41
    private val reqAudio = 42
    private val ui = Handler(Looper.getMainLooper())

    private lateinit var powerBtn: TextView
    private lateinit var statusText: TextView
    private lateinit var heardText: TextView
    private lateinit var stopSoundBtn: Button
    private lateinit var modelText: TextView
    private lateinit var modelBar: ProgressBar
    private lateinit var retryBtn: Button
    private lateinit var chipAlarm: TextView
    private lateinit var chipMp3: TextView
    private lateinit var mp3Text: TextView
    private var downloading = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun c(hex: String) = Color.parseColor(hex)

    private fun bg(color: Int, radius: Int, stroke: Int = 0): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radius).toFloat()
        if (stroke != 0) d.setStroke(dp(1), stroke)
        return d
    }

    private fun lp(w: Int, h: Int, top: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.topMargin = dp(top)
        return p
    }

    private fun label(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = value
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(t.typeface, Typeface.BOLD)
        return t
    }

    private fun card(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(18), dp(16), dp(18), dp(18))
        l.background = bg(c("#1AFFFFFF"), 20, c("#22FFFFFF"))
        return l
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        if (!ModelManager.isReady(this)) startDownload()
        refreshModelUi()
        updateChips()
    }

    private fun buildScreen() {
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
        val white = Color.WHITE
        val soft = c("#9FB0C7")

        val scroll = ScrollView(this)
        scroll.isFillViewport = true
        scroll.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR, intArrayOf(c("#0B1220"), c("#241052"))
        )
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(20), dp(48), dp(20), dp(56))
        scroll.addView(root, ViewGroup.LayoutParams(match, wrap))

        val title = label("VOICE BOOST", 28f, white, true)
        title.gravity = Gravity.CENTER
        root.addView(title, lp(match, wrap))
        val sub = label("TOCA UM SOM QUANDO VOCÊ DIZ A PALAVRA", 11f, soft)
        sub.gravity = Gravity.CENTER
        sub.setPadding(0, dp(6), 0, 0)
        root.addView(sub, lp(match, wrap))

        // Botão principal
        powerBtn = TextView(this)
        powerBtn.gravity = Gravity.CENTER
        powerBtn.textSize = 20f
        powerBtn.setTextColor(white)
        powerBtn.setTypeface(powerBtn.typeface, Typeface.BOLD)
        powerBtn.setOnClickListener { onPowerClick() }
        val pl = lp(dp(170), dp(170), 30)
        pl.gravity = Gravity.CENTER_HORIZONTAL
        root.addView(powerBtn, pl)
        setPowerStyle(false)

        statusText = label("Desligado", 17f, c("#FFC857"), true)
        statusText.gravity = Gravity.CENTER
        root.addView(statusText, lp(match, wrap, 20))
        heardText = label("", 12f, soft)
        heardText.gravity = Gravity.CENTER
        root.addView(heardText, lp(match, wrap, 6))

        stopSoundBtn = Button(this)
        stopSoundBtn.text = "PARAR SOM"
        stopSoundBtn.setTextColor(white)
        stopSoundBtn.background = bg(c("#E5484D"), 14)
        stopSoundBtn.visibility = View.GONE
        stopSoundBtn.setOnClickListener {
            startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_STOP_SOUND))
        }
        root.addView(stopSoundBtn, lp(match, dp(52), 12))

        // Card: palavra
        val c1 = card()
        c1.addView(label("PALAVRA DE ATIVAÇÃO", 12f, soft, true))
        val wordInput = EditText(this)
        wordInput.setText(Prefs.word(this))
        wordInput.hint = "Ex.: socorro"
        wordInput.setTextColor(white)
        wordInput.setHintTextColor(c("#7C8AA5"))
        wordInput.textSize = 18f
        wordInput.inputType = InputType.TYPE_CLASS_TEXT
        wordInput.isSingleLine = true
        wordInput.background = bg(c("#33000000"), 14, c("#33FFFFFF"))
        wordInput.setPadding(dp(16), dp(12), dp(16), dp(12))
        wordInput.doAfterTextChanged { Prefs.setWord(this, it?.toString()?.trim() ?: "") }
        c1.addView(wordInput, lp(match, wrap, 10))
        c1.addView(label("Pode ser uma palavra ou frase curta. A alteração vale na hora.", 11f, soft), lp(match, wrap, 8))
        root.addView(c1, lp(match, wrap, 26))

        // Card: som
        val c2 = card()
        c2.addView(label("SOM QUE VAI TOCAR", 12f, soft, true))
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        chipAlarm = label("Alarme padrão", 14f, white, true)
        chipMp3 = label("Meu MP3", 14f, white, true)
        for (chip in listOf(chipAlarm, chipMp3)) {
            chip.gravity = Gravity.CENTER
            chip.setPadding(0, dp(12), 0, dp(12))
        }
        chipAlarm.setOnClickListener { Prefs.setSource(this, "alarm"); updateChips() }
        chipMp3.setOnClickListener {
            if (File(filesDir, "custom_audio").exists()) { Prefs.setSource(this, "mp3"); updateChips() } else pickMp3()
        }
        val half = LinearLayout.LayoutParams(0, wrap, 1f)
        half.setMargins(0, 0, dp(6), 0)
        val half2 = LinearLayout.LayoutParams(0, wrap, 1f)
        half2.setMargins(dp(6), 0, 0, 0)
        row.addView(chipAlarm, half)
        row.addView(chipMp3, half2)
        c2.addView(row, lp(match, wrap, 10))
        mp3Text = label("", 12f, soft)
        c2.addView(mp3Text, lp(match, wrap, 10))
        val pick = Button(this)
        pick.text = "ESCOLHER ARQUIVO MP3"
        pick.setTextColor(white)
        pick.background = bg(c("#33FFFFFF"), 14)
        pick.setOnClickListener { pickMp3() }
        c2.addView(pick, lp(match, dp(48), 10))
        root.addView(c2, lp(match, wrap, 14))

        // Card: modelo de voz
        val c3 = card()
        c3.addView(label("RECONHECIMENTO DE VOZ", 12f, soft, true))
        modelText = label("", 14f, white)
        c3.addView(modelText, lp(match, wrap, 8))
        modelBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        modelBar.max = 100
        c3.addView(modelBar, lp(match, wrap, 8))
        retryBtn = Button(this)
        retryBtn.text = "BAIXAR NOVAMENTE"
        retryBtn.setTextColor(white)
        retryBtn.background = bg(c("#2F6BFF"), 14)
        retryBtn.setOnClickListener { startDownload() }
        c3.addView(retryBtn, lp(match, dp(48), 10))
        root.addView(c3, lp(match, wrap, 14))

        val warn = label(
            "Dica: para funcionar com a tela apagada, deixe o app sem restrição de bateria nas configurações do Android. " +
                "Cuidado: o volume sobe ao máximo, não use perto do ouvido.", 11f, soft
        )
        warn.gravity = Gravity.CENTER
        root.addView(warn, lp(match, wrap, 18))

        setContentView(scroll)
    }

    private fun setPowerStyle(on: Boolean) {
        val d = GradientDrawable()
        d.shape = GradientDrawable.OVAL
        d.setColor(if (on) c("#E5484D") else c("#2F6BFF"))
        d.setStroke(dp(7), if (on) c("#55FF8A8D") else c("#554F86FF"))
        powerBtn.background = d
        powerBtn.text = if (on) "DESLIGAR" else "LIGAR"
    }

    private fun updateChips() {
        val useMp3 = Prefs.source(this) == "mp3" && File(filesDir, "custom_audio").exists()
        chipAlarm.background = if (!useMp3) bg(c("#2F6BFF"), 14) else bg(c("#22FFFFFF"), 14)
        chipMp3.background = if (useMp3) bg(c("#2F6BFF"), 14) else bg(c("#22FFFFFF"), 14)
        val name = Prefs.mp3Name(this)
        mp3Text.text = if (name.isNotEmpty() && File(filesDir, "custom_audio").exists()) "Arquivo: $name" else "Nenhum MP3 escolhido ainda"
    }

    private fun pickMp3() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "audio/*"
        startActivityForResult(i, reqAudio)
    }

    @Deprecated("Legacy picker result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqAudio && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            thread {
                try {
                    contentResolver.openInputStream(uri)?.use { input ->
                        File(filesDir, "custom_audio").outputStream().use { out -> input.copyTo(out) }
                    }
                    Prefs.setMp3Name(this, displayName(uri))
                    Prefs.setSource(this, "mp3")
                    runOnUiThread { updateChips() }
                } catch (e: Exception) {
                    runOnUiThread { Toast.makeText(this, "Não consegui abrir esse arquivo.", Toast.LENGTH_LONG).show() }
                }
            }
        }
    }

    private fun displayName(uri: Uri): String {
        var name = "arquivo selecionado"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cur ->
            if (cur.moveToFirst()) name = cur.getString(0) ?: name
        }
        return name
    }

    private fun startDownload() {
        if (downloading) return
        downloading = true
        modelBar.progress = 0
        refreshModelUi()
        thread {
            val ok = ModelManager.download(this) { p -> runOnUiThread { modelBar.progress = p } }
            runOnUiThread {
                downloading = false
                refreshModelUi()
                if (!ok) Toast.makeText(this, "Falha ao baixar o modelo.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun refreshModelUi() {
        when {
            ModelManager.isReady(this) -> {
                modelText.text = "Pronto ✓ (funciona sem internet)"
                modelText.setTextColor(c("#38D6A3"))
                modelBar.visibility = View.GONE
                retryBtn.visibility = View.GONE
            }
            downloading -> {
                modelText.text = "Baixando modelo de voz em português (~31 MB)…"
                modelText.setTextColor(Color.WHITE)
                modelBar.visibility = View.VISIBLE
                retryBtn.visibility = View.GONE
            }
            else -> {
                val why = ModelManager.lastError
                modelText.text = if (why.isEmpty()) "Modelo ainda não baixado. Conecte à internet."
                else "Falha ao baixar: $why"
                modelText.setTextColor(c("#FFC857"))
                modelBar.visibility = View.GONE
                retryBtn.visibility = View.VISIBLE
            }
        }
    }

    private fun onPowerClick() {
        if (VoiceService.running) {
            startService(Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_QUIT))
            return
        }
        if (!ModelManager.isReady(this)) {
            Toast.makeText(this, "Aguarde o download do modelo de voz.", Toast.LENGTH_LONG).show()
            return
        }
        if (Prefs.word(this).isBlank()) {
            Toast.makeText(this, "Digite a palavra de ativação.", Toast.LENGTH_LONG).show()
            return
        }
        if (Prefs.source(this) == "mp3" && !File(filesDir, "custom_audio").exists()) Prefs.setSource(this, "alarm")
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val missing = perms.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isEmpty()) startVoiceService() else requestPermissions(missing.toTypedArray(), reqPerm)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqPerm) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startVoiceService()
            } else {
                Toast.makeText(this, "A permissão do microfone é necessária.", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startVoiceService() {
        VoiceService.lastError = ""
        ContextCompat.startForegroundService(
            this, Intent(this, VoiceService::class.java).setAction(VoiceService.ACTION_START)
        )
    }

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            ui.postDelayed(this, 400)
        }
    }

    private fun refresh() {
        val on = VoiceService.running
        setPowerStyle(on)
        val err = VoiceService.lastError
        when {
            VoiceService.playing -> {
                statusText.text = "🔊 TOCANDO!"
                statusText.setTextColor(c("#38D6A3"))
            }
            on -> {
                statusText.text = "● OUVINDO “${Prefs.word(this)}”"
                statusText.setTextColor(c("#38D6A3"))
            }
            err.isNotEmpty() -> {
                statusText.text = "Erro: $err"
                statusText.setTextColor(c("#FF8A8D"))
            }
            else -> {
                statusText.text = "● DESLIGADO"
                statusText.setTextColor(c("#FFC857"))
            }
        }
        heardText.text = if (on && VoiceService.lastHeard.isNotEmpty()) "Ouvi: ${VoiceService.lastHeard}" else ""
        stopSoundBtn.visibility = if (VoiceService.playing) View.VISIBLE else View.GONE
    }

    override fun onResume() {
        super.onResume()
        ui.post(tick)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(tick)
    }
}
