package com.voiceboost.app

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

object ModelManager {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-pt-0.3.zip"

    fun modelDir(c: Context): File = File(c.filesDir, "vosk-model")
    fun isReady(c: Context): Boolean = File(modelDir(c), "am").exists() && File(modelDir(c), "conf").exists()

    /** Baixa e extrai o modelo de voz em português. Rodar fora da thread principal. */
    fun download(c: Context, onProgress: (Int) -> Unit): Boolean {
        val tmp = File(c.cacheDir, "model.zip")
        return try {
            val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 15000
            conn.readTimeout = 30000
            val total = conn.contentLength
            conn.inputStream.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(32 * 1024)
                    var done = 0L
                    var n = 0
                    while (input.read(buf).also { n = it } >= 0) {
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress((done * 90 / total).toInt())
                    }
                }
            }
            val dir = modelDir(c)
            dir.deleteRecursively()
            dir.mkdirs()
            val base = dir.canonicalPath
            ZipInputStream(tmp.inputStream().buffered()).use { zin ->
                var e = zin.nextEntry
                while (e != null) {
                    val name = e.name.substringAfter('/', "")
                    if (name.isNotEmpty()) {
                        val f = File(dir, name)
                        if (!f.canonicalPath.startsWith(base)) throw SecurityException("zip inválido")
                        if (e.isDirectory) {
                            f.mkdirs()
                        } else {
                            f.parentFile?.mkdirs()
                            f.outputStream().use { zin.copyTo(it) }
                        }
                    }
                    e = zin.nextEntry
                }
            }
            tmp.delete()
            onProgress(100)
            isReady(c)
        } catch (e: Exception) {
            modelDir(c).deleteRecursively()
            tmp.delete()
            false
        }
    }
}
