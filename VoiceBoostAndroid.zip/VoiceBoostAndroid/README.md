# Voice Boost — Android

Projeto inicial Android nativo em Kotlin.

## O que faz
- Monitora o microfone enquanto a tela do app está aberta.
- Detecta um som alto sustentado por aproximadamente 350 ms.
- Aumenta gradualmente o volume de mídia até o máximo.
- Reproduz em loop um MP3 escolhido pelo usuário ou o alarme padrão do Android.
- O botão PARAR interrompe o som e o monitoramento.

## Como abrir e instalar
1. Instale o Android Studio em um computador.
2. Extraia a pasta `VoiceBoostAndroid`.
3. No Android Studio, escolha **Open** e selecione essa pasta.
4. Aguarde a sincronização do Gradle e a instalação do Android SDK 35, se solicitada.
5. Conecte o celular por USB com Depuração USB ativada ou use um emulador.
6. Clique em Run e permita o acesso ao microfone.

## Observações
- O limite inicial está em `-18 dBFS` por 350 ms, em `MainActivity.kt`. Microfones variam; ajuste após testar.
- O app mede intensidade sonora, não identifica semanticamente um grito. Música ou ruído alto também podem ativá-lo.
- O áudio toca pelo canal de mídia (`STREAM_MUSIC`).
- O app só monitora enquanto a tela está em primeiro plano; ao sair da tela, para por segurança.
- Alguns aparelhos/versões do Android podem limitar alterações de volume.
- Teste com cuidado e não use som alto perto dos ouvidos: volumes elevados podem causar danos auditivos.
- Este é o código-fonte do projeto, não um APK assinado/publicado.
