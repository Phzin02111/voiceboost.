package com.voiceboost.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.media.RingtoneManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlin.concurrent.thread
import kotlin.math.log10
import kotlin.math.sqrt

class MainActivity : Activity() {
    private val permissionRequest = 41
    private val audioPickerRequest = 42
    private lateinit var audioManager: AudioManager
    private lateinit var statusText: TextView
    private lateinit var levelText: TextView
    private lateinit var selectedText: TextView
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var sourceGroup: RadioGroup
    private var selectedMp3: Uri? = null
    private var selectedSource = "alarm"
    @Volatile private var monitoring = false
    @Volatile private var playing = false
    private var recorder: AudioRecord? = null
    private var player: MediaPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var screamStartedAt = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        buildScreen()
        updateVolumeLabel()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 32, 28, 28)
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(0xFF101827.toInt())
        }
        fun label(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
            }

        root.addView(label("VOICE BOOST", 28f), LinearLayout.LayoutParams(-1, -2))
        root.addView(label("AMPLIFICADOR ATIVADO POR GRITO", 12f, 0xFF9FB0C7.toInt()).apply {
            setPadding(0, 8, 0, 28)
        })
        statusText = label("● DESATIVADO", 19f, 0xFFFFC857.toInt())
        root.addView(statusText, LinearLayout.LayoutParams(-1, -2))
        levelText = label("Volume: ${currentVolumePercent()}%", 22f).apply { setPadding(0, 24, 0, 24) }
        root.addView(levelText)
        root.addView(label("ESCOLHA O ÁUDIO", 15f, 0xFF9FB0C7.toInt()).apply { setPadding(0, 12, 0, 8) })

        sourceGroup = RadioGroup(this).apply { orientation = RadioGroup.VERTICAL; setPadding(12, 8, 12, 8) }
        val alarmRadio = RadioButton(this).apply {
            text = "Alarme padrão do celular"; setTextColor(0xFFFFFFFF.toInt()); id = View.generateViewId(); isChecked = true
        }
        val mp3Radio = RadioButton(this).apply {
            text = "Meu arquivo MP3"; setTextColor(0xFFFFFFFF.toInt()); id = View.generateViewId()
        }
        sourceGroup.addView(alarmRadio)
        sourceGroup.addView(mp3Radio)
        sourceGroup.setOnCheckedChangeListener { _, checkedId -> selectedSource = if (checkedId == mp3Radio.id) "mp3" else "alarm" }
        root.addView(sourceGroup, LinearLayout.LayoutParams(-1, -2))

        val pickButton = makeButton("ESCOLHER MP3")
        pickButton.setOnClickListener { openMp3Picker() }
        root.addView(pickButton, buttonParams())
        selectedText = label("Áudio: alarme padrão", 13f, 0xFF9FB0C7.toInt()).apply { setPadding(0, 8, 0, 18) }
        root.addView(selectedText)

        startButton = makeButton("INICIAR MONITORAMENTO")
        startButton.setOnClickListener { requestAndStart() }
        root.addView(startButton, buttonParams())
        stopButton = makeButton("PARAR / DESLIGAR SOM").apply {
            isEnabled = false; alpha = 0.55f; setOnClickListener { stopEverything() }
        }
        root.addView(stopButton, buttonParams())
        root.addView(label("O som será repetido até você apertar PARAR. O microfone só é monitorado enquanto esta tela estiver aberta.", 12f, 0xFF9FB0C7.toInt()).apply {
            setPadding(8, 22, 8, 0)
        })
        setContentView(root)
    }

    private fun makeButton(value: String) = Button(this).apply { text = value; isAllCaps = false; textSize = 15f }
    private fun buttonParams() = LinearLayout.LayoutParams(-1, 56).apply { setMargins(0, 7, 0, 7) }

    private fun openMp3Picker() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "audio/*" }
        startActivityForResult(intent, audioPickerRequest)
    }

    @Deprecated("Legacy picker result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == audioPickerRequest && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            selectedMp3 = uri
            selectedText.text = "MP3: ${displayName(uri)}"
            sourceGroup.check(sourceGroup.getChildAt(1).id)
        }
    }

    private fun displayName(uri: Uri): String {
        var name = "arquivo selecionado"
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
        }
        return name
    }

    private fun requestAndStart() {
        if (selectedSource == "mp3" && selectedMp3 == null) {
            Toast.makeText(this, "Escolha um arquivo MP3 primeiro.", Toast.LENGTH_LONG).show(); return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), permissionRequest)
        } else startMonitoring()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startMonitoring()
        else if (requestCode == permissionRequest) Toast.makeText(this, "A permissão do microfone é necessária.", Toast.LENGTH_LONG).show()
    }

    private fun startMonitoring() {
        if (monitoring) return
        val sampleRate = 16000
        val minBuffer = AudioRecord.getMinBufferSize(sampleRate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuffer <= 0) { Toast.makeText(this, "Não foi possível iniciar o microfone.", Toast.LENGTH_LONG).show(); return }
        try {
            recorder = AudioRecord(MediaRecorder.AudioSource.MIC, sampleRate, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuffer, sampleRate))
            if (recorder?.state != AudioRecord.STATE_INITIALIZED) {
                Toast.makeText(this, "Microfone indisponível.", Toast.LENGTH_LONG).show(); recorder?.release(); recorder = null; return
            }
            monitoring = true
            screamStartedAt = 0L
            recorder?.startRecording()
            statusText.text = "● OUVINDO — AGUARDANDO GRITO"
            statusText.setTextColor(0xFF38D6A3.toInt())
            startButton.isEnabled = false; stopButton.isEnabled = true; stopButton.alpha = 1f

            thread(name = "VoiceBoostMic") {
                val buffer = ShortArray(1024)
                while (monitoring) {
                    val count = try { recorder?.read(buffer, 0, buffer.size) ?: -1 } catch (_: Exception) { -1 }
                    if (count > 0 && !playing) {
                        var sum = 0.0
                        for (i in 0 until count) { val v = buffer[i].toDouble(); sum += v * v }
                        val rms = sqrt(sum / count)
                        val db = if (rms > 0) 20.0 * log10(rms / 32768.0) else -90.0
                        runOnUiThread { levelText.text = "Intensidade do som: ${db.toInt()} dB" }
                        // Limite inicial: -18 dBFS durante 350 ms; ajuste conforme o aparelho.
                        if (db >= -18.0) {
                            if (screamStartedAt == 0L) screamStartedAt = System.currentTimeMillis()
                            if (System.currentTimeMillis() - screamStartedAt >= 350) {
                                runOnUiThread { onScreamDetected() }; screamStartedAt = 0L
                            }
                        } else screamStartedAt = 0L
                    } else if (count < 0) break
                }
            }
        } catch (e: Exception) {
            monitoring = false
            Toast.makeText(this, "Erro ao acessar o microfone: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun onScreamDetected() {
        if (!monitoring || playing) return
        statusText.text = "GRITO DETECTADO! AUMENTANDO VOLUME..."
        statusText.setTextColor(0xFFFFC857.toInt())
        rampVolumeThenPlay()
    }

    private fun rampVolumeThenPlay() {
        val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val startVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val steps = 12
        var step = 0
        val ramp = object : Runnable {
            override fun run() {
                if (!monitoring) return
                step++
                val next = (startVolume + (maxVolume - startVolume) * step / steps).coerceIn(0, maxVolume)
                audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, next, 0)
                updateVolumeLabel()
                if (step < steps) handler.postDelayed(this, 120) else playSelectedAudio()
            }
        }
        handler.post(ramp)
    }

    private fun playSelectedAudio() {
        if (!monitoring || playing) return
        val uri = if (selectedSource == "mp3") selectedMp3 else
            (RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION))
        if (uri == null) { Toast.makeText(this, "Não encontrei um áudio para reproduzir.", Toast.LENGTH_LONG).show(); return }
        try {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setAudioStreamType(AudioManager.STREAM_MUSIC)
                isLooping = true
                setOnPreparedListener {
                    if (!monitoring) { it.release(); return@setOnPreparedListener }
                    playing = true; it.start()
                    statusText.text = "● SOM TOCANDO — REPETINDO"
                    statusText.setTextColor(0xFF38D6A3.toInt())
                }
                setOnErrorListener { mp, _, _ ->
                    playing = false; mp.release(); player = null
                    runOnUiThread {
                        statusText.text = "Erro ao reproduzir áudio"
                        Toast.makeText(this@MainActivity, "Não foi possível tocar esse áudio.", Toast.LENGTH_LONG).show()
                    }
                    true
                }
                prepareAsync()
            }
        } catch (e: Exception) {
            playing = false
            Toast.makeText(this, "Erro no áudio: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun stopEverything() {
        monitoring = false; playing = false
        handler.removeCallbacksAndMessages(null)
        try { recorder?.stop() } catch (_: Exception) { }
        recorder?.release(); recorder = null
        try { player?.stop() } catch (_: Exception) { }
        player?.release(); player = null
        if (::statusText.isInitialized) {
            statusText.text = "● DESATIVADO"; statusText.setTextColor(0xFFFFC857.toInt())
            startButton.isEnabled = true; stopButton.isEnabled = false; stopButton.alpha = 0.55f
            updateVolumeLabel()
        }
    }

    private fun currentVolumePercent(): Int {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max == 0) 0 else current * 100 / max
    }
    private fun updateVolumeLabel() { if (::levelText.isInitialized) levelText.text = "Volume: ${currentVolumePercent()}%" }

    override fun onPause() { super.onPause(); stopEverything() }
    override fun onDestroy() { stopEverything(); super.onDestroy() }
}
